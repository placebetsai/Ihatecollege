// pages/rank.js
import RankYourSchool from "./rank-your-school";
export default RankYourSchool;
